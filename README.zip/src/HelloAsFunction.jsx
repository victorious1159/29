function HelloAsFunction({a,b}){
    return <>{(parseInt(a)/parseInt(b))}</>
}
export default HelloAsFunction;